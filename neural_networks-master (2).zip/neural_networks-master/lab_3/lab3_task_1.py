import torch
import random
x = torch.randn(5,3)

x = x.to(dtype=torch.int)
print('integer tensor: ')
print(x)

z = x**3
print('tensor powered by 3: ')
print(z)

z *= random.randint(1, 10)
print('rand multiplied tensor: ')
print(z)

e = torch.exp(z)
print('exponent tensor: ')
print(e)
